package co.edu.uniquindio.proyecto.modelo.entidades;

public class Reseña {
}
