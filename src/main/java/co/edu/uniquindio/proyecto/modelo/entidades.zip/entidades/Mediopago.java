package co.edu.uniquindio.proyecto.modelo.entidades;

public enum Mediopago {
    TARJETA_CREDITO,
    TARJETA_DEBITO,
    PAYPAL,
    EFECTIVO,
    TRANSFERENCIA_BANCARIA
}